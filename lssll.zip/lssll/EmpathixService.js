class EmpathixService {
    constructor() {
        this.emotionRules = {
            "joy": 0.1,
            "calm": 0.2,
            "anxiety": 0.7,
            "anger": 0.85
        };
    }

    calculateStressScore(emotion, pulse) {
        if (!this.emotionRules.hasOwnProperty(emotion)) {
            throw new Error(`Unknown emotion: ${emotion}`);
        }
        if (pulse < 40 || pulse > 200) {
            throw new RangeError("Pulse out of realistic range (40-200)");
        }

        let baseFactor = this.emotionRules[emotion];
        let pulseFactor = (pulse - 60) / 140;
        if (pulseFactor < 0) pulseFactor = 0;

        let score = (baseFactor * 0.6 + pulseFactor * 0.4) * 100;
        return Math.min(Math.round(score), 100);
    }

    evaluateStateSeverity(stressScore, durationMinutes) {
        if (stressScore < 0 || stressScore > 100) {
            throw new Error("Invalid stress score");
        }
        if (durationMinutes <= 0) return "Normal";

        if (stressScore >= 75 && durationMinutes >= 15) {
            return "Critical";
        } else if (stressScore >= 50 && durationMinutes >= 10) {
            return "Warning";
        }
        return "Normal";
    }

    getAverageStress(sessions) {
        if (!Array.isArray(sessions) || sessions.length === 0) {
            return 0;
        }

        let total = 0;
        let validCount = 0;

        for (let i = 0; i < sessions.length; i++) {
            if (typeof sessions[i] === 'number' && sessions[i] >= 0 && sessions[i] <= 100) {
                total += sessions[i];
                validCount++;
            }
        }

        return validCount > 0 ? Math.round(total / validCount) : 0;
    }
}

module.exports = EmpathixService;