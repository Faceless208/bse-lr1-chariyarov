const EmpathixService = require('./EmpathixService');

describe('EmpathixService Unit Tests', () => {
    let service;

    beforeEach(() => {
        service = new EmpathixService();
    });

    test('TC-01: Should calculate stress for valid emotion and pulse', () => {
        const result = service.calculateStressScore('joy', 70);
        expect(result).toBe(9);
    });

    test('TC-02: Should throw error for unknown emotion', () => {
        expect(() => {
            service.calculateStressScore('excited', 80);
        }).toThrow('Unknown emotion');
    });

    test('TC-03: Should throw RangeError if pulse is below 40', () => {
        expect(() => {
            service.calculateStressScore('calm', 39);
        }).toThrow(RangeError);
    });

    test('TC-04: Should process successfully if pulse is exactly 40', () => {
        const result = service.calculateStressScore('calm', 40);
        expect(result).toBe(12);
    });

    test('TC-05: Should process successfully if pulse is exactly 200', () => {
        const result = service.calculateStressScore('anger', 200);
        expect(result).toBe(91);
    });

    test('TC-06: Should throw RangeError if pulse is above 200', () => {
        expect(() => {
            service.calculateStressScore('anger', 201);
        }).toThrow(RangeError);
    });

    test('TC-07: Should return Critical on exact boundary', () => {
        const severity = service.evaluateStateSeverity(75, 15);
        expect(severity).toBe('Critical');
    });

    test('TC-08: Should return Warning if score is just below Critical boundary', () => {
        const severity = service.evaluateStateSeverity(74, 15);
        expect(severity).toBe('Warning');
    });

    test('TC-09: Should return Warning on exact Warning boundary', () => {
        const severity = service.evaluateStateSeverity(50, 10);
        expect(severity).toBe('Warning');
    });

    test('TC-10: Should return Normal if score is just below Warning boundary', () => {
        const severity = service.evaluateStateSeverity(49, 10);
        expect(severity).toBe('Normal');
    });

    test('TC-11: Should return 0 for empty session array', () => {
        const avg = service.getAverageStress([]);
        expect(avg).toBe(0);
    });

    test('TC-12: Should calculate average and ignore non-number dirty data', () => {
        const avg = service.getAverageStress([40, 'corrupted', 60, 200, -5]);
        expect(avg).toBe(50);
    });
});